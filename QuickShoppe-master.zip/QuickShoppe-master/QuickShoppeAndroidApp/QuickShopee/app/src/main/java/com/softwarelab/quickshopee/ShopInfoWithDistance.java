package com.softwarelab.quickshopee;

/**
 * Created by rehan on 6/11/17.
 */

public class ShopInfoWithDistance {
        shopInfo info;
        String distance;
        ShopInfoWithDistance(shopInfo info,String distance){
            this.info=info;
            this.distance=distance;
        }

}
